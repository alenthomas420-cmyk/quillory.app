import { Mail, MessageCircle, Book, Bug } from 'lucide-react';

type Page = 'home' | 'how-it-works' | 'faq' | 'privacy' | 'support';

const supportOptions = [
  {
    icon: Mail,
    title: 'Email Support',
    description: 'Get help from our team via email. We typically respond within 24 hours.',
    action: 'support@quillory.app',
    buttonText: 'Send Email',
  },
  {
    icon: MessageCircle,
    title: 'Common Questions',
    description: 'Find answers to frequently asked questions about Quillory.',
    action: 'faq',
    buttonText: 'View FAQ',
  },
  {
    icon: Book,
    title: 'Documentation',
    description: 'Learn how to use Quillory with our step-by-step guides.',
    action: 'how-it-works',
    buttonText: 'Read Docs',
  },
  {
    icon: Bug,
    title: 'Report a Bug',
    description: 'Found an issue? Let us know so we can fix it quickly.',
    action: 'bugs@quillory.app',
    buttonText: 'Report Bug',
  },
];

export function Support() {
  return (
    <div className="bg-white min-h-screen py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Support Center
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We're here to help. Choose the option that works best for you.
          </p>
        </div>

        {/* Support Options */}
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8 mb-16">
          {supportOptions.map((option, index) => (
            <div
              key={index}
              className="p-8 border border-gray-200 rounded-2xl hover:shadow-lg transition-all bg-white group"
            >
              <div className="w-14 h-14 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <option.icon className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {option.title}
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {option.description}
              </p>
              <button
                onClick={() => {
                  if (option.action.includes('@')) {
                    window.location.href = `mailto:${option.action}`;
                  }
                }}
                className="text-emerald-600 hover:text-emerald-700 font-medium inline-flex items-center gap-2 group-hover:gap-3 transition-all"
              >
                {option.buttonText}
                <span>→</span>
              </button>
            </div>
          ))}
        </div>

        {/* Troubleshooting Tips */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Quick Troubleshooting
          </h2>

          <div className="space-y-6">
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
              <h3 className="font-semibold text-gray-900 mb-3">
                Recording Issues
              </h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Check that Quillory has microphone permissions enabled in your device settings</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Ensure your device isn't in silent mode or Do Not Disturb</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Try restarting the app or your device</span>
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
              <h3 className="font-semibold text-gray-900 mb-3">
                Summary Not Generating
              </h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Check your internet connection—summaries require online processing</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Wait a few moments—AI processing may take up to 30 seconds</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Try recording again with clearer audio</span>
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
              <h3 className="font-semibold text-gray-900 mb-3">
                Login Problems
              </h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Double-check your email and password for typos</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Use the "Forgot Password" link to reset your credentials</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Ensure you're using the latest version of the app</span>
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
              <h3 className="font-semibold text-gray-900 mb-3">
                Data & Privacy Concerns
              </h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Review our Privacy Policy for detailed information on data handling</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>You can export or delete your data anytime from app settings</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 mt-1">•</span>
                  <span>Contact us directly for account-specific privacy questions</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Contact CTA */}
        <div className="max-w-4xl mx-auto mt-16 bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-2xl p-8 md:p-12 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            Still need help?
          </h3>
          <p className="text-emerald-100 mb-6 text-lg">
            Our support team is ready to assist you with any questions or issues.
          </p>
          <a
            href="mailto:support@quillory.app"
            className="inline-flex items-center gap-2 px-6 py-3 bg-white text-emerald-700 rounded-lg hover:bg-emerald-50 transition-colors font-semibold"
          >
            <Mail className="w-5 h-5" />
            Contact Support Team
          </a>
        </div>
      </div>
    </div>
  );
}
