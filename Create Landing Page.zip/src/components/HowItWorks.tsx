import { Mic, FileText, Settings, Calendar } from 'lucide-react';

const steps = [
  {
    icon: Mic,
    title: 'Tap & Record',
    description: 'Open Quillory and tap the microphone button. Speak your thoughts naturally—no typing needed.',
    detail: 'Record as little or as much as you want. Your voice is captured with high quality.',
  },
  {
    icon: FileText,
    title: 'AI Generates Summary',
    description: 'Our AI automatically processes your recording and creates a clean, concise summary of your entry.',
    detail: 'Summaries capture the essence of your thoughts while maintaining your personal voice.',
  },
  {
    icon: Settings,
    title: 'Customize Tone',
    description: 'Choose how your summaries sound—Balanced, Yourself, or other preset tones that match your style.',
    detail: 'Adjust settings anytime to make summaries feel more personal or professional.',
  },
  {
    icon: Calendar,
    title: 'Build Your Habit',
    description: 'Come back daily to record and reflect. Watch your collection of memories grow over time.',
    detail: 'Track your progress and revisit past entries to see your personal growth.',
  },
];

export function HowItWorks() {
  return (
    <div className="bg-white min-h-screen py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-20">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            How Quillory Works
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            A simple, four-step process designed for effortless voice journaling. No friction, no complexity—just tap, record, and reflect.
          </p>
        </div>

        {/* Steps */}
        <div className="max-w-4xl mx-auto space-y-16">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative"
            >
              {/* Step Number */}
              <div className="flex items-start gap-8">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg">
                    <step.icon className="w-8 h-8" />
                  </div>
                  <div className="text-sm text-emerald-600 font-bold mt-3 text-center">
                    STEP {index + 1}
                  </div>
                </div>

                <div className="flex-1 pt-2">
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    {step.title}
                  </h3>
                  <p className="text-lg text-gray-700 mb-3 leading-relaxed">
                    {step.description}
                  </p>
                  <p className="text-gray-600 leading-relaxed">
                    {step.detail}
                  </p>
                </div>
              </div>

              {/* Connecting Line */}
              {index < steps.length - 1 && (
                <div className="absolute left-8 top-20 w-0.5 h-12 bg-emerald-200"></div>
              )}
            </div>
          ))}
        </div>

        {/* Example Summary Section */}
        <div className="max-w-4xl mx-auto mt-32">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Example Daily Summary
            </h2>
            <p className="text-lg text-gray-600">
              See how Quillory transforms your voice recordings into thoughtful summaries.
            </p>
          </div>

          <div className="bg-gradient-to-br from-emerald-50 to-white border border-emerald-100 rounded-2xl p-8 md:p-12 shadow-lg">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-emerald-600 flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-semibold text-gray-900">Today's Reflection</div>
                <div className="text-sm text-gray-600">January 29, 2026</div>
              </div>
            </div>

            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 leading-relaxed italic">
                "Today was productive. I started the morning with a walk and felt refreshed afterward. Work was busy but manageable—I completed the project I've been working on for weeks. Feeling grateful for the small wins and looking forward to unwinding this evening with a book."
              </p>
            </div>

            <div className="mt-6 pt-6 border-t border-emerald-100">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Tone: <span className="font-medium text-gray-900">Balanced</span></span>
                <span className="text-gray-600">2m recording → 45s summary</span>
              </div>
            </div>
          </div>
        </div>

        {/* Customization Info */}
        <div className="max-w-4xl mx-auto mt-20 bg-white border border-gray-200 rounded-2xl p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Customizable Design
              </h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Quillory adapts to your preferences. Choose summary tones, adjust settings, and personalize your journaling experience to match your style.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-gray-700">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-600"></div>
                  Multiple tone options
                </li>
                <li className="flex items-center gap-2 text-gray-700">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-600"></div>
                  Privacy controls
                </li>
                <li className="flex items-center gap-2 text-gray-700">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-600"></div>
                  Flexible recording lengths
                </li>
              </ul>
            </div>
            <div className="bg-emerald-50 rounded-xl p-6 flex items-center justify-center">
              <Settings className="w-24 h-24 text-emerald-600" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
