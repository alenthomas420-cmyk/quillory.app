import { Mic, Lock, Sparkles, ArrowRight, Download } from 'lucide-react';
import logo from 'figma:asset/68e599128d4d7b361a8d0cf92dadbb4aef5582c0.png';

type Page = 'home' | 'how-it-works' | 'faq' | 'privacy' | 'support';

interface HomeProps {
  onNavigate: (page: Page) => void;
}

const features = [
  {
    icon: Mic,
    title: 'Voice Recordings',
    description: 'Tap, record, and go. Capture your thoughts effortlessly with a single tap.',
  },
  {
    icon: Sparkles,
    title: 'AI-Generated Summaries',
    description: 'Get clean, concise summaries of your daily reflections automatically.',
  },
  {
    icon: Lock,
    title: 'Complete Privacy',
    description: 'Your memories remain yours. We never monetize or share your data.',
  },
];

export function Home({ onNavigate }: HomeProps) {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/50 to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 rounded-full mb-8">
              <Mic className="w-4 h-4 text-emerald-700" />
              <span className="text-sm text-emerald-700 font-medium">Voice-first journaling</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 tracking-tight">
              Your memories,
              <br />
              <span className="text-emerald-600">captured effortlessly</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed">
              A minimalistic, private voice journaling app designed for daily reflection and personal growth.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="flex items-center justify-center gap-2 px-8 py-4 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/30 hover:shadow-xl hover:shadow-emerald-600/40">
                <Download className="w-5 h-5" />
                Download Now
              </button>
              <button
                onClick={() => onNavigate('how-it-works')}
                className="flex items-center justify-center gap-2 px-8 py-4 border-2 border-gray-200 text-gray-700 rounded-xl hover:border-emerald-600 hover:text-emerald-600 transition-colors"
              >
                See How it Works
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Decorative element */}
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-emerald-200 to-transparent"></div>
      </section>

      {/* What You Get Section */}
      <section className="py-20 md:py-32 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What You Get
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Everything you need for a calm, distraction-free journaling experience.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl border border-gray-100 hover:border-emerald-200 hover:shadow-lg transition-all bg-white group"
              >
                <div className="w-14 h-14 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Daily Consistency Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-white to-emerald-50/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                  Build a daily reflection habit
                </h2>
                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                  Quillory makes journaling effortless. No friction, no clutter—just tap, record, and go. Perfect for busy individuals who value personal growth and mindfulness.
                </p>
                <ul className="space-y-4">
                  {[
                    'Record voice notes in seconds',
                    'AI-powered daily summaries',
                    'Customizable tone for summaries',
                    'Private and secure by design',
                  ].map((item, index) => (
                    <li key={index} className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                        <div className="w-2 h-2 rounded-full bg-emerald-600"></div>
                      </div>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative">
                <div className="aspect-square rounded-3xl bg-emerald-100 overflow-hidden">
                  <img
                    src={logo}
                    alt="Quillory App"
                    className="w-full h-full object-contain p-12"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-3xl p-12 md:p-16 text-center shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Start your journaling journey today
            </h2>
            <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
              Join thousands who are building a daily reflection habit with Quillory.
            </p>
            <button className="px-8 py-4 bg-white text-emerald-700 rounded-xl hover:bg-emerald-50 transition-colors font-semibold shadow-lg inline-flex items-center gap-2">
              <Download className="w-5 h-5" />
              Download for Free
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
