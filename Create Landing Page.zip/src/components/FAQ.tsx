import { ChevronDown } from 'lucide-react';
import { useState } from 'react';

const faqs = [
  {
    question: 'Is my data private?',
    answer: 'Absolutely. Quillory is built with privacy at its core. Your voice recordings and summaries are encrypted and stored securely. We never share, sell, or monetize your personal data. You have complete control over your content.',
  },
  {
    question: 'Who can access my recordings?',
    answer: 'Only you. Your recordings and summaries are private and accessible only through your account. We use industry-standard encryption to ensure your data remains secure and confidential.',
  },
  {
    question: 'Can I delete my data?',
    answer: 'Yes, you have full control. You can delete individual recordings, summaries, or your entire account at any time. Once deleted, your data is permanently removed from our servers.',
  },
  {
    question: 'Is Quillory free?',
    answer: 'Quillory offers a free tier with core features including voice recording and AI summaries. Premium features and additional storage options are available through our subscription plans.',
  },
  {
    question: 'What happens to my voice recordings?',
    answer: 'Your voice recordings are processed by our AI to generate summaries, then stored securely in your private account. You can listen to original recordings anytime or delete them if you prefer to keep only the summaries.',
  },
  {
    question: 'Can I export my data?',
    answer: 'Yes. You can export all your recordings and summaries in common formats (audio files and text). This ensures you always have access to your memories, even outside the app.',
  },
  {
    question: 'How accurate are the AI summaries?',
    answer: 'Our AI is designed to capture the essence of your thoughts accurately. While summaries are highly accurate, they are meant for personal reflection—not as medical or professional advice. You can always review and edit summaries.',
  },
  {
    question: 'What devices is Quillory available on?',
    answer: 'Quillory is currently available on iOS and Android devices. We\'re working on a web version to make your memories accessible across all platforms.',
  },
  {
    question: 'How do I change the summary tone?',
    answer: 'You can customize the summary tone in the app settings. Choose from preset options like "Balanced," "Yourself," or others that match your personal style. Changes apply to future summaries.',
  },
  {
    question: 'Is there a recording time limit?',
    answer: 'Free users can record up to 5 minutes per entry. Premium subscribers have extended recording limits to capture longer reflections and memories.',
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="bg-white min-h-screen py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need to know about Quillory. Can't find what you're looking for? Contact our support team.
          </p>
        </div>

        {/* FAQ List */}
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="border border-gray-200 rounded-xl overflow-hidden bg-white hover:shadow-md transition-shadow"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
              >
                <span className="font-semibold text-gray-900 pr-4">
                  {faq.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-600 flex-shrink-0 transition-transform ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openIndex === index && (
                <div className="px-6 pb-5">
                  <p className="text-gray-600 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact Section */}
        <div className="max-w-3xl mx-auto mt-16 bg-emerald-50 border border-emerald-100 rounded-2xl p-8 text-center">
          <h3 className="text-xl font-bold text-gray-900 mb-3">
            Still have questions?
          </h3>
          <p className="text-gray-600 mb-6">
            Our support team is here to help. Reach out anytime.
          </p>
          <button className="px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium">
            Contact Support
          </button>
        </div>
      </div>
    </div>
  );
}
