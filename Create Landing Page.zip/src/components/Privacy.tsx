import { Shield, Lock, Eye, FileText } from 'lucide-react';

export function Privacy() {
  return (
    <div className="bg-white min-h-screen py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-100 rounded-2xl mb-6">
            <Shield className="w-8 h-8 text-emerald-600" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Privacy Policy
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your privacy is our priority. Here's how we protect your data and respect your rights.
          </p>
          <p className="text-sm text-gray-500 mt-4">
            Last updated: January 29, 2026
          </p>
        </div>

        {/* Key Principles */}
        <div className="max-w-4xl mx-auto mb-16">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-xl text-center">
              <Lock className="w-8 h-8 text-emerald-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Encrypted</h3>
              <p className="text-sm text-gray-600">All data is encrypted in transit and at rest</p>
            </div>
            <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-xl text-center">
              <Eye className="w-8 h-8 text-emerald-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Private</h3>
              <p className="text-sm text-gray-600">Your data is never shared or sold</p>
            </div>
            <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-xl text-center">
              <FileText className="w-8 h-8 text-emerald-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Yours</h3>
              <p className="text-sm text-gray-600">You control your data completely</p>
            </div>
          </div>
        </div>

        {/* Policy Content */}
        <div className="max-w-4xl mx-auto prose prose-lg">
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">What We Collect</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Quillory collects only the information necessary to provide you with a seamless journaling experience:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li><strong>Account Information:</strong> Email address and password (encrypted)</li>
              <li><strong>Voice Recordings:</strong> Audio files you choose to record</li>
              <li><strong>Generated Summaries:</strong> AI-processed text summaries of your recordings</li>
              <li><strong>Usage Data:</strong> Basic analytics to improve app performance (anonymized)</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">How We Use Your Data</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Your data serves one purpose: to provide you with the best journaling experience.
            </p>
            <ul className="space-y-2 text-gray-700">
              <li><strong>Voice Recordings:</strong> Processed by AI to generate summaries, then stored securely in your account</li>
              <li><strong>Summaries:</strong> Displayed in your app for reflection and review</li>
              <li><strong>Account Data:</strong> Used for authentication and account management</li>
              <li><strong>Analytics:</strong> Anonymized data helps us improve features and fix bugs</li>
            </ul>
            <p className="text-gray-700 leading-relaxed mt-4">
              <strong>We never:</strong> Sell your data, share it with third parties for marketing, or use it for purposes beyond providing our service.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Rights & Control</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              You have complete control over your data:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li><strong>Access:</strong> View all your recordings and summaries anytime</li>
              <li><strong>Export:</strong> Download your data in standard formats</li>
              <li><strong>Delete:</strong> Remove individual entries or your entire account</li>
              <li><strong>Modify:</strong> Edit or update your account information</li>
              <li><strong>Opt-out:</strong> Disable analytics tracking in settings</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Data Security</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              We implement industry-standard security measures:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li>End-to-end encryption for all data transmission</li>
              <li>Encrypted storage for recordings and summaries</li>
              <li>Secure authentication with password hashing</li>
              <li>Regular security audits and updates</li>
              <li>GDPR and CCPA compliant data practices</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">AI Content Disclaimer</h2>
            <p className="text-gray-700 leading-relaxed">
              Summaries generated by Quillory's AI are intended for personal reflection and self-awareness. They should not be considered:
            </p>
            <ul className="space-y-2 text-gray-700 mt-4">
              <li>Medical or mental health advice</li>
              <li>Professional counseling or therapy</li>
              <li>Legal or financial guidance</li>
              <li>A substitute for professional consultation</li>
            </ul>
            <p className="text-gray-700 leading-relaxed mt-4">
              If you need professional support, please consult a qualified expert.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Data Retention</h2>
            <p className="text-gray-700 leading-relaxed">
              Your data is stored as long as your account is active. When you delete your account, all associated data (recordings, summaries, and account information) is permanently removed from our servers within 30 days.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Changes to This Policy</h2>
            <p className="text-gray-700 leading-relaxed">
              We may update this Privacy Policy periodically. Significant changes will be communicated via email or in-app notification. Continued use of Quillory after updates constitutes acceptance of the new policy.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Us</h2>
            <p className="text-gray-700 leading-relaxed">
              Questions about privacy or data handling? We're here to help.
            </p>
            <p className="text-gray-700 mt-4">
              <strong>Email:</strong> <a href="mailto:privacy@quillory.app" className="text-emerald-600 hover:text-emerald-700">privacy@quillory.app</a>
            </p>
          </section>
        </div>

        {/* Bottom CTA */}
        <div className="max-w-4xl mx-auto mt-16 bg-emerald-50 border border-emerald-100 rounded-2xl p-8 text-center">
          <h3 className="text-xl font-bold text-gray-900 mb-3">
            Your privacy matters
          </h3>
          <p className="text-gray-600 mb-6">
            We're committed to transparency and protecting your personal information. If you have concerns, reach out anytime.
          </p>
          <button className="px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium">
            Contact Support
          </button>
        </div>
      </div>
    </div>
  );
}
