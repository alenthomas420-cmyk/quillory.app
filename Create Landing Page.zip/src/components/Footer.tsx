import logo from 'figma:asset/68e599128d4d7b361a8d0cf92dadbb4aef5582c0.png';

type Page = 'home' | 'how-it-works' | 'faq' | 'privacy' | 'support';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleNavigate = (page: Page) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-50 border-t border-gray-100">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img src={logo} alt="Quillory" className="h-10 w-10" />
              <span className="text-xl font-semibold text-gray-900">quillory</span>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed">
              Voice-first journaling for daily reflection and personal growth.
            </p>
          </div>

          {/* Product */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Product</h3>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => handleNavigate('how-it-works')}
                  className="text-gray-600 hover:text-emerald-600 transition-colors text-sm"
                >
                  How it Works
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavigate('faq')}
                  className="text-gray-600 hover:text-emerald-600 transition-colors text-sm"
                >
                  FAQ
                </button>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-emerald-600 transition-colors text-sm">
                  Download
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => handleNavigate('privacy')}
                  className="text-gray-600 hover:text-emerald-600 transition-colors text-sm"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-emerald-600 transition-colors text-sm">
                  Terms of Service
                </a>
              </li>
              <li>
                <button
                  onClick={() => handleNavigate('support')}
                  className="text-gray-600 hover:text-emerald-600 transition-colors text-sm"
                >
                  Support
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Contact</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="mailto:support@quillory.app"
                  className="text-gray-600 hover:text-emerald-600 transition-colors text-sm"
                >
                  support@quillory.app
                </a>
              </li>
              <li>
                <a
                  href="mailto:privacy@quillory.app"
                  className="text-gray-600 hover:text-emerald-600 transition-colors text-sm"
                >
                  privacy@quillory.app
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-200">
          <p className="text-center text-gray-600 text-sm">
            © {currentYear} Quillory. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
