import { useState } from 'react';
import { Home } from './components/Home';
import { HowItWorks } from './components/HowItWorks';
import { FAQ } from './components/FAQ';
import { Privacy } from './components/Privacy';
import { Support } from './components/Support';
import { Navigation } from './components/Navigation';
import { Footer } from './components/Footer';

type Page = 'home' | 'how-it-works' | 'faq' | 'privacy' | 'support';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onNavigate={setCurrentPage} />;
      case 'how-it-works':
        return <HowItWorks />;
      case 'faq':
        return <FAQ />;
      case 'privacy':
        return <Privacy />;
      case 'support':
        return <Support />;
      default:
        return <Home onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />
      <main>{renderPage()}</main>
      <Footer onNavigate={setCurrentPage} />
    </div>
  );
}
